#############################################################################
### 	Author - Python Programmer                               ############
###		Description - Python Math Module                         ############
### 	Date - 23-09-2023                                        ############
###																 ############
#############################################################################

#calculator  +,-,/,*   sum,sub,multiply,divide are known as user defined function 

#(a+b)**2
def sqroftwo(a,b) :  
    result = (a+b)*(a+b)
    return result