#############################################################################
### 	Author - Python Programmer                               ############
###		Description - Python String module                       ############
### 	Date - 23-09-2023                                        ############
###																 ############
#############################################################################

#string length 
def stringlen(s) : 
    length = len(s)
    return length
    
    
    